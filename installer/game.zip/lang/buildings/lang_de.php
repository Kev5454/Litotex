<?PHP

BUILDING_ABORT = Abbrechen
BUILDING_ERROR_1 = Configuration ERROR
BUILDING_ERROR_2 = Fehlerhafter Seitenaufruf
BUILDING_ERROR_3 = Nicht gen&uuml;gend Land vorhanden
BUILDING_ERROR_4 = Du kannst dieses Geb&auml;ude noch nicht bauen
BUILDING_ERROR_5 = Nicht gen&uuml;gend Ressourcen vorhanden
BUILDING_ERROR_6 = Dieses Geb&auml;ude ist schon Stufe 0
BUILDING_ERROR_7 = Auf diesm Land befindet sich nichts in Bau
BUILDING_NONE = #
BUILDING_1 = es wird gebaut
BUILDING_2 = Name
BUILDING_3 = Beschreibung
BUILDING_4 = Kosten
BUILDING_5 = Bauzeit
BUILDING_6 = Gr&ouml;&szlig;e
BUILDING_7 = Aktion
BUILDING_8 = Bebaute Baufl&auml;che
BUILDING_9 = Bau
BUILDING_10 = Abriss
BUILDING_11 = es fehlen:
?>
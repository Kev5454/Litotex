<?PHP
ADMIN_LOGIN="Fehler bei der Anmeldung.<br>Als Administrator ist aus Sicherheitsgr&uuml;nden die Anmeldung im Spiel nicht erlaubt ! "
GLOBAL_MSG_TEXT="neue Nachrichten"
MODUL_LOAD_ERROR="Das Modul wurde vom Administrator deaktiviert"
LOGIN_ERROR="Du bist nicht, oder nicht mehr angemeldet! "
LANG_NOT_FOUND_ERROR = "Die Sprache wurde nicht gefunden! Bitte w�hlen sie eine andere Sprache aus!";
GLOBAL_STORE_SIZE="Lager: "
?>
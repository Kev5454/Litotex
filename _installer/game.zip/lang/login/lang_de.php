<?PHP
ELELM_DESC1="Beschreibung";
LOGIN_ERROR_1="Bitte usernamen und Kennwort angeben."
LOGIN_ERROR_2="Unbekannter User oder falsches Kennwort Kennwort."


?>
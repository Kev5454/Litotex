<?PHP

BUILDING_ABORT = Abbrechen
BUILDING_ERROR_1 = Configuration ERROR

BUILD_UNITS_NONE = #
BUILD_UNITS_1 = Name
BUILD_UNITS_2 = Beschreibung
BUILD_UNITS_3 = Kosten
BUILD_UNITS_4 = Bauzeit
BUILD_UNITS_5 = Anzahl
BUILD_UNITS_6 = Aktion
BUILD_UNITS_7 = "Ausbilden"
BUILD_UNITS_8 = N&auml;chste Einheit
BUILD_UNITS_9 = Auftrag fertig
BUILD_UNITS_10 = Warteschleife
BUILD_UNITS_11 = Abbrechen
BUILD_UNITS_12 = Bicht ge&uuml;gend Ressourcen vorhanden
BUILD_UNITS_13 = vorhanden
BUILD_UNITS_14 = Fehlerhafte Eingabe
BUILD_UNITS_15 = Auf diesm Land befindet sich nichts in Bau
BUILD_UNITS_16 = AP
BUILD_UNITS_17 = VP
BUILD_UNITS_18 = "Ausbildung"
?>
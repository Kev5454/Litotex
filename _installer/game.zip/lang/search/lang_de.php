<?PHP
SERACH_TEXT="Suchen nach Spieler"
SERACH_TEXT_0="Bitte mindestens 2 Buchstaben eingeben."
SEARCH_TEXT_1="Suche nach User"
BUTTON_TEXT="Suche starten"
SEARCH_ERROR_1="Bitte mindestens 2 Buchstaben eingeben !!!"
SEARCH_UNAME="Username"
SEARCH_IMG="Bild"
SEARCH_POINTS="Punkte"
SEARCH_ALI="Allianz"
SEARCH_LAST="letztes Login"
?>
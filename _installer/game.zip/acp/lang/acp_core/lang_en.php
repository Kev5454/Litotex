<?PHP
ELELM_DESC1="Description"
ELELM_DESC2="Number"
ELEMENT1 = "Number of players"
ELEMENT2="Number of blocked players"
ELEMENT3="Number of active players"
ELEMENT4="Card size"
ELEMENT5="Number of countries"
ELEMENT6="Number of free countries"

?>
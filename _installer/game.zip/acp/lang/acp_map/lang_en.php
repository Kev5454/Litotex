LANDSIZE = "Land Size"
LANDELEMENT1="Number of Lakes"
LANDELEMENT2="Number of Mountains"
BUTTONSAVE="Save Settings"
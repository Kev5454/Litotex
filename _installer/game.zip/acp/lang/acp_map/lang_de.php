LANDSIZE = "Landgr&ouml;&szlig;e"
LANDELEMENT1="Anzahl Seen"
LANDELEMENT2="Anzahl Berge"
BUTTONSAVE="Einstellungen speichern"
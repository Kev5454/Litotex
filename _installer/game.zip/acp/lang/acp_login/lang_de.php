ln_login_e_1="Bitte Usernamen UND Kennwort eingeben";
ln_login_e_2="Der Username und/oder das Kennwort ist falsch";
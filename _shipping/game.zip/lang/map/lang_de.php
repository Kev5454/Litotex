<?PHP
MAP_SHOW ="Karte"
?>
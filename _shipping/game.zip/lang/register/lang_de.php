<?PHP
REGISTER_ERROR_1="Die Registrierung wurde vom Administrator deaktiviert"
REGISTER_ERROR_2="Bitte Username und kennwort eingeben."
REGISTER_ERROR_3="Bitte unseren Spielregeln zustimmen."
REGISTER_ERROR_4="Der Usernamen muss aus 3-15 Buchstaben bestehen und darf keine Sonderzeichen enthalten ( bis auf - und _ ) ."
REGISTER_ERROR_5="Falsche E-mail Format."
REGISTER_ERROR_6="Der Username wird bereits verwendrt."
REGISTER_ERROR_7="Die Mailadresse wird bereits verwendrt."
REGISTER_ERROR_8="Der Username ist gesperrt."
REGISTER_SUBMIT_OK="Vielen dank f&uuml;r deine Registrierung.<br /> das Kennwort wurde dir per Mail zugestellt."
LN_NOTE_REGISTER_1="Achtung: Bitte eine korrekte E-Mail Adresse angeben!"
LN_NOTE_REGISTER_2=F&uuml;r die erfolgreiche Registrierung bitte einfach deinen gew&uuml;nschten Benutzernamen und Emailadresse angeben.<br />Die Passwort&uuml;bermittlung erfolgt per eMail!
LN_NOTE_REGISTER_3="Benutzerregeln und Spieleregeln"
LN_REGISTER_NAME="Registrieren"
LN_NAME_USERNAME="Benutzername"
LN_NAME_EMAIL="eMail"
IN_REGISTER_P_6="Registrieren"
LN_NOTE_REGISTER_FOROTT_1="Passwort vergessen"
LN_NOTE_REGISTER_FOROTT_2="Der Username konnte nicht gefunden werden.";
LN_NOTE_REGISTER_FOROTT_3="Die Mailadresse konnte nicht gefunden werden.";
LN_NOTE_REGISTER_FOROTT_4="Die wurde ein neues Kennwort per Email zugestellt.";
LN_REGISTTER_P_2="Hier kannst du dir dein Passwort zuschicken lassen"
LN_REGISTTER_P_5="Senden"
BADWORD_FOUND="Dieser Username ist nicht erlaubt."
?>
&uuml;
<?PHP

BUILD_DEFF_ERROR_1 = Fehlerhafte Eingabe
BUILD_DEFF_ERROR_2 = Bicht ge&uuml;gend Ressourcen vorhanden
BUILD_DEFF_ERROR_3 = Auf diesm Land befindet sich nichts in Bau


BUILD_DEFF_NONE = #
BUILD_DEFF_1 = Name
BUILD_DEFF_2 = Anzahl
BUILD_DEFF_3 = N&auml;chste Einheit
BUILD_DEFF_4 = Auftrag fertig
BUILD_DEFF_5 = Aktion
BUILD_DEFF_7 = Beschreibung
BUILD_DEFF_8 = Kosten
BUILD_DEFF_9 = Bauzeit
BUILD_DEFF_10 = "Ausbilden"
BUILD_DEFF_11 = Abbrechen
BUILD_DEFF_12 = "Warteschleife"
BUILD_DEFF_13 = vorhanden
BUILD_DEFF_14 = AP
BUILD_DEFF_15 = VP
BUILD_DEFF_16 = "Status"
?>
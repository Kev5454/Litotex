<?php

SCREEN_NAME_TITLE="Screenshots"
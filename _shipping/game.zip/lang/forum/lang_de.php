<?PHP
//ali_forum.html
ln_allianz_forum_1 = "Willkommen im Forum"
ln_allianz_forum_2 = "Hier habt ihr die M&ouml;glichkeit euch untereinander auszutauschen."
ln_allianz_forum_3 = "Allianz Board"
ln_allianz_forum_4 = "Hier hast du die M&ouml;glichkeit f&uuml;r das Allianzforum <br>verschiedene Kategorien einzurichten"
ln_allianz_forum_5 = "Allianzforum-Einstellungen"
ln_allianz_forum_6 = "Kategorie"
ln_allianz_forum_7 = "Beschreibung"
ln_allianz_forum_8 = "Aktion"
ln_allianz_forum_9 = "Kategorie"
ln_allianz_forum_10 = "Beschreibung"
ln_allianz_forum_11 = "Anlegen"
ln_allianz_forum_12 = "Nachrichten verfassen"
ln_allianz_forum_13 = "Betreff"
ln_allianz_forum_14 = "Text"
ln_forum_o_1 = "Forum"
ln_forum_o_2 = "Themen"
ln_forum_o_3 = "Antworten"
ln_forum_o_4 = "Views"
ln_forum_o_5 = "Ersteller"
ln_forum_o_6 = "Letzter Poster"
ln_forum_err_1 = "Zugriff verweigert!"
ln_error_8 = "Fehlender Titel!"
ln_error_9 = "Fehlender Text!"
ln_error_10 = "Du bist zu dieser Funktion nicht berechtigt!"
ln_error_11 = "Du bist in keiner Allianz.<br>Diese Funktion steht dir erst nach Eintritt zur Verf&uuml;gung."



?>
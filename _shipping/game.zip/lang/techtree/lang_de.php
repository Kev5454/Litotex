<?PHP
T_Row_1="Geb&auml;ude"
T_Row_2="Einheiten"
T_Row_3="Forschungen"
T_req_1="Ben&ouml;tigt"
T_req_2="Vorhanden"
T_desc_1="Image"
T_desc_2="Name"

?>
<?PHP
PIC_UPLOAD_USER="Bildupload"
PIC_UPLOAD_USER_DEL="L&ouml;schen"
PIC_UPLOAD_USER_DESC= "Hier hast du die M&ouml;glichkeit dein Userbild hochzuladen.<br>Bitte beachte, dass das Bild nicht gr&ouml;&szlig;er als 200 KByte sein darf.<br>Es werden nur Bilder vom Typ jpg unterst&uuml;tzt.<br>"
PIC_UPLOAD_USER_DESC1 = "Lege Hier dein Avantarbild fest."
PIC_UPLOAD_USER_UPLOAD="Upload"
PIC_UPLOAD_USER_SAVE="Speichern"
PIC_UPLOAD_ERROR_1="Falsches Dateiformat angegeben:<br> Es werden nur .jpg - Dateien akzeptiert!"
PIC_UPLOAD_ERROR_2="Falsches Dateiformat oder die Datei ist zu gro&szlig;!"

ln_pic_1 = "Lege hier dein Alianzbild fest."
ln_pic_2 = "Hier hast Du die M&ouml;glichkeit ein Allianzbild hochzuladen .<br>Bitte beachte, dass das Bild nicht gr&ouml;&szlig;er als 200 KByte sein darf.<br>Aus rechtlichen Gr&uuml;nden werden nur Bilder des Types jpg erlaubt."
ln_pic_3 = "Die optiomale Gr&ouml;&szlig;e f&uuml;r einen Allianzbanner betr&auml;gt 468*60 Pixel.<br>Das Bild, welches du hier hochladen kannst, wird automatisch an diese Gr&ouml;&szlig;e angepasst."
ln_members_u_20 = "Datei senden"
ln_allianz_c_r_12 = "speichern"
?>
<?PHP

EXPLORE = Forschen
EXPLORE_ABORT = Abbrechen
EXPLORE_NONE = #
EXPLORE_NAME = Name

EXPLORING_1 = Beschreibung
EXPLORING_2 = Kosten
EXPLORING_3 = Bauzeit
EXPLORING_4 = Aktion

EXPLORING_ERROR_1 = Fehlerhafter Seitenaufruf
EXPLORING_ERROR_2 = Du kannst diese Forschung noch nicht erforschen
EXPLORING_ERROR_3 = Nicht gen&uuml;gend Rohstoffe
EXPLORING_ERROR_4 = Auf diesm Land wird nichts geforscht
EXPLORING_ERROR_5 = Forschung kann nicht abgebrochen werden
EXPLORING_ERROR_6 = Es wird bereits geforscht
?>
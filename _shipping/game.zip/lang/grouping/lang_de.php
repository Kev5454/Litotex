<?PHP

GROUPING_ERROR_1 = Soviele Einheiten stehen nicht zur Verf&uuml;gung
GROUPING_ERROR_2 = Es wurde eine fehlerhafte Gruppe ausgew&auml;hlt
GROUPING_ERROR_3 = Du haste eine Gruppe ausgew&auml;hlt, die nicht dir geh&ouml;rt

GROUPING_1 = Truppen
GROUPING_2 = Geschwindigkeit
GROUPING_3 = Aktion
GROUPING_3 = "l&ouml;schen"
GROUPING_4 = Hier kannst du Kampftruppen bilden, mit denen du k&auml;mpfen kannst
GROUPING_5 = Hinzuf&uuml;gen
GROUPING_6 = Name
GROUPING_7 = "erstellen"
GROUPING_8 = "entladen"
GROUPING_9 = "Meine Gruppen"
GROUPING_10 = "Gruppen bilden"
?>
<?PHP

NEW_LAND_1 = Koordinaten
NEW_LAND_2 = Ankunft
NEW_LAND_3 = nach
NEW_LAND_4 = Neues Land suchen?
NEW_LAND_5 = X
NEW_LAND_52 = Y
NEW_LAND_6 = Dieses Land um 10 erweitern 
NEW_LAND_7 = Landgr&uuml;nder verf&uuml;gbar:
NEW_LAND_8 = Landgr&ouml;&szlig;e
NEW_LAND_9 = max.
NEW_LAND_10 = "Suche starten"
NEW_LAND_11 = Landgr&uuml;ndung erfolgreich
NEW_LAND_12 = Die Landgr&uuml;ndung war erfolgreich, dir wurde ein neues Land zugewiesen
NEW_LAND_13 = Landk&auml;mpfer ist gestorben!
NEW_LAND_14 = Landgr&uuml;ndung nicht erfolgreich
NEW_LAND_15 = Der Landgr&uuml;nder hat keine freie Fl&auml;che gefunden!
NEW_LAND_16 = Die Landgr&uuml;ndung war leider nicht erfolgreich!

NEW_LAND_ERROR_1 = Kein Landgr&uuml;nder vorhanden!
NEW_LAND_ERROR_2 = Fehlerhafte Eingabe!
NEW_LAND_ERROR_3 = Du hast schon $op_max_lands L&auml;nder oder es sind schon zu viele Landgr&uuml;nder unterwegs, weitere L&auml;nder kannst du nicht erorbern!
NEW_LAND_ERROR_4 = maximale L&auml;ndergr&ouml;&szlig;e erreicht
?>
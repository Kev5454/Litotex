<?PHP
LN_SPION_3 = "Spionage auf Land"
LN_SPION_1 = "Spionage auf"
LN_SPION_2 = Leider nicht erfolgreich!
LN_SPION_E_1 = "Zu wenige Spione vorhanden!"
LN_SPION_E_2= "Land wurde nicht gefunden!"
LN_SPION_E_3 = Du verf&uuml;gst &uuml;ber
LN_SPION_4  = Ankunft
LN_SPION_5  = Spionage auf Land starten
LN_SPION_6  = Spione : 
LN_SPION_7  = Spionage starten
LN_SPION_8  = senden
LN_SPION_9  = Spione Unterwegs
LN_SPION_10  = Koordinaten z.b. 91:53
LN_SPION_NUMBER= Anzahl
LN_SPION_KOORD_ERROR= "Fehlerhafte Eingabe"
LN_SPION_SPIO_ERROR="fehlerhafte Eingabe der Anzahl"
LN_SPION_SPIO_L="Das Land konnte leider nicht gefunden werden."

?>
<?PHP
ELELM_DESC1="Beschreibung"
ELELM_DESC2="Aktion"
ELELM_DESC3 = "Alle l�schen : "
ELELM_DESC4 = "Alle Traceausgaben werden in der Datenbank gel�scht."
ELELM_DESC5 = "Debug Level : "
ELELM_DESC6 = "User : "
ELELM_DESC7 = "Alle User"
ELELM_DESC8 = "Ausf�hren"
ELELM_DESC9 = "ID"
ELELM_DESC10 = "Level"
ELELM_DESC11 = "User ID"
ELELM_DESC12 = "Nachricht"
ELELM_DESC13  = "Zeit"
ELELM_DESC14  = "Zu dieser Funktion nicht berechtigt!"



?>
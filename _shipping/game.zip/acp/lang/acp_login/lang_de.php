<?PHP

/*
 	************************************************************
 	Litotex Browsergame - Engine
 	http://www.Litotex.de
 	http://www.freebg.de

  Copyright (c) 2008 FreeBG Team
 	************************************************************
	Hinweis:
  Diese Software ist urheberrechtlich gesch�tzt.

  F�r jegliche Fehler oder Sch�den, die durch diese Software
  auftreten k�nnten, �bernimmt der Autor keine Haftung.
  
  Alle Copyright - Hinweise innerhalb dieser Datei 
  d�rfen WEDER entfernt, NOCH ver�ndert werden. 
  ************************************************************
  Released under the GNU General Public License 
  ************************************************************  

 */
 
$ln_login_e_1="Bitte Usernamen UND Kennwort eingeben";
$ln_login_e_2="Der Username und/oder das Kennwort ist falsch";

?>
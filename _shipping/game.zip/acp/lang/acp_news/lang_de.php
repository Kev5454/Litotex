<?PHP
NEWS_SAVE_BUTTON ="News speichern"
NEW_NEWS_TITLE_TEXT ="Bitte trage hier eine neue Nachricht ein.<br>Diese kannst du anschlie&szlig;end in der &Uuml;bersicht freischalten."
NEW_NEWS_OVER_TEXT ="&Uuml;berschrift"
NEWS_IS_ACTIV_TEXT="aktivieren"
NEWS_DATUM_TEXT="Datum"
NEWS_ID_TEXT="Lfd. ID"
NEWS_DELETE_TEXT="l&ouml;schen"
NEWS_ACTIVATE_TEXT="aktivieren"
NEWS_DEACTIVATE_TEXT="deaktivieren"
NEWS_LIST_TEXT="News &Uuml;bersicht.<br>Hier kannst du News f&uuml;r die Startseite aktivieren, oder auch deaktivieren."
?>
<?PHP

$dbhost = "localhost";
$dbuser = "#USERNAME#";
$dbpassword = "#PASSWORD#";
$dbbase = "#DATENBANK#";

$litotex_path = "/var/www/vhosts/makrotex.de/httpdocs/"; // Bearbeite diese Zeile
$litotex_url = "https://makrotex.de/"; // Bearbeite diese Zeile
$n = 1;
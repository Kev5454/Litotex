
LOGIN_ERROR_1 = "Bitte Usernamen UND Kennwort eingeben"
LOGIN_ERROR_2 = "Der Username und/oder das Kennwort ist falsch"


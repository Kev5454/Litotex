
url_open_on="Dein Webspace unterst�tzt das automatische Download."
url_open_off="Dein Webspace unterst�tzt das automatische Download nicht.<br>Der Provider hat die Funktion 'allow_url_fopen' in der PHP-INI deaktiviert.Aus diesem grunde kann kein automatisches Update erfolgen.<br>Dir werden nur die neuen Versionsnummern angezeigt."

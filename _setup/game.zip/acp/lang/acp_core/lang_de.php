
ELELM_DESC1="Beschreibung"
ELELM_DESC2="Anzahl"
ELEMENT1 = "Anzahl Spieler"
ELEMENT2="Anzahl gesperrte Spieler"
ELEMENT3="Anzahl aktive Spieler"
ELEMENT4="Kartengr&ouml;&szlig;e"
ELEMENT5="Anzahl L&auml;nder"
ELEMENT6="Anzahl freie L&auml;nder"

